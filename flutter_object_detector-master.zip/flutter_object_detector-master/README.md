# object_detector

A flutter application using tensorflow and Yolo for object detection. (Just support Android yet)

## Getting Started

For help getting started with Flutter, view our online
[documentation](https://flutter.io/).

## Donate
If you find it is interesting, consider buy me a cup of coffee:
[Donation](https://paypal.me/maithang)
